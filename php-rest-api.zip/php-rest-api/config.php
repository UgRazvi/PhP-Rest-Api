<?php

$conn = mysqli_connect("localhost", "root", "", "php_rest_api")
    or die("Connection Failed");

// if(!$conn){
//     die("Connection Failed");
// }
// else{
//     echo("Connection is successfully made");
// }

?>

